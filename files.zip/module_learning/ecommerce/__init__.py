print('ecommerce initialized')
